import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  delay
} from "@whiskeysockets/baileys";
import P from "pino";
import fs from "fs";
import readline from "readline";

const PREFIX = process.env.PREFIX || ".";
const SESSION_DIR = "./session";
const GIF_URL = process.env.MENU_GIF_URL || "";
const logger = P({ level: "silent" });

const menuText = `
╭━━━「 🎌 SPOPO BOT V2 」━━━╮
┃
┃ 🎌 ANIME MENU
┃ └ .menu
┃
┃ 🤖 BOT
┃ ├ .ping
┃ ├ .alive
┃ ├ .owner
┃ └ .info
┃
┃ 🚀 PHASE 1
┃ └ Pairing Code + Session
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯
`;

function ask(question) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(resolve => rl.question(question, answer => {
    rl.close();
    resolve(answer.trim());
  }));
}

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);

  const sock = makeWASocket({
    auth: state,
    logger,
    browser: ["SPOPO BOT", "Chrome", "1.0.0"],
    markOnlineOnConnect: false,
    syncFullHistory: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "open") {
      console.log("\n✅ SPOPO BOT connected successfully!");
      console.log("🤖 Bot is ready. Type .menu in WhatsApp.\n");
    }

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) {
        console.log("🔄 Connection closed. Reconnecting...");
        setTimeout(startBot, 3000);
      } else {
        console.log("❌ Logged out. Delete ./session and pair again.");
      }
    }
  });

  // Pairing Code: only on first run.
  if (!sock.authState?.creds?.registered && !state.creds.registered) {
    let number = process.env.BOT_NUMBER;

    if (!number) {
      number = await ask("📱 Enter WhatsApp number (international format, no +): ");
    }

    number = number.replace(/\D/g, "");

    if (!number) {
      console.log("❌ Invalid phone number.");
      process.exit(1);
    }

    await delay(2500);

    try {
      const code = await sock.requestPairingCode(number);
      console.log("\n🔐 PAIRING CODE:", code);
      console.log("📲 WhatsApp > Settings > Linked Devices > Link a Device > Link with phone number");
      console.log("⚠️ Keep this terminal open while pairing.\n");
    } catch (err) {
      console.error("❌ Could not request pairing code:", err?.message || err);
    }
  }

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const m = messages?.[0];
    if (!m?.message) return;
    if (m.key?.fromMe) return;

    const jid = m.key.remoteJid;
    if (!jid) return;

    const text =
      m.message.conversation ||
      m.message.extendedTextMessage?.text ||
      m.message.imageMessage?.caption ||
      m.message.videoMessage?.caption ||
      "";

    if (!text.startsWith(PREFIX)) return;

    const [commandRaw] = text.slice(PREFIX.length).trim().split(/\s+/);
    const command = (commandRaw || "").toLowerCase();

    if (command === "menu") {
      try {
        if (GIF_URL) {
          await sock.sendMessage(jid, {
            video: { url: GIF_URL },
            caption: menuText,
            gifPlayback: true
          });
        } else {
          await sock.sendMessage(jid, { text: menuText });
        }
      } catch (err) {
        console.log("⚠️ GIF failed, sending text menu:", err?.message || err);
        await sock.sendMessage(jid, { text: menuText });
      }
      return;
    }

    if (command === "ping") {
      await sock.sendMessage(jid, { text: "🏓 Pong! SPOPO BOT شغال ✅" });
      return;
    }

    if (command === "alive") {
      await sock.sendMessage(jid, {
        text: "🤖 SPOPO BOT V2\n🟢 Online\n🎌 Phase 1"
      });
      return;
    }

    if (command === "owner") {
      await sock.sendMessage(jid, {
        text: "👑 OWNER\nSPOPO BOT\n\nبدّل معلومات المالك من بعد فالنسخة الجاية."
      });
      return;
    }

    if (command === "info") {
      await sock.sendMessage(jid, {
        text: "🤖 SPOPO BOT V2\n⚡ Phase 1\n🔐 Pairing Code\n💾 Session محفوظة\n🎌 Anime Menu"
      });
      return;
    }
  });
}

startBot().catch(err => {
  console.error("❌ Fatal error:", err);
});
