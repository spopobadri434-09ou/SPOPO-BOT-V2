# SPOPO BOT V2 — Phase 1

## شنو كاين؟
- اتصال WhatsApp عبر Baileys
- Pairing Code
- حفظ Session داخل `session/`
- `.menu`
- GIF في `.menu` إذا حطيتي رابط GIF مباشر في `.env`
- `.ping`
- `.alive`
- `.owner`
- `.info`

## المتطلبات
Node.js 20 أو أحدث.

## التشغيل
1. حل Terminal داخل مجلد المشروع.
2. نسخ `.env.example` إلى `.env`.
3. حط رقم واتساب ديال البوت في `BOT_NUMBER` بلا `+` وبلا مسافات.
4. إذا بغيتي GIF: حط رابط مباشر لملف GIF في `MENU_GIF_URL`.
5. شغل:
   npm install
   npm start
6. خذ Pairing Code من Terminal وربط الرقم من WhatsApp:
   Settings > Linked Devices > Link a Device > Link with phone number

## مهم
- ما تمسحش مجلد `session/` من بعد الربط، حيث فيه بيانات الجلسة.
- إذا بغيتي تبدل الحساب المرتبط، وقف البوت، مسح `session/`، وشغلو من جديد.
